 function btn() {
      alert("Страничка еще не создана");
    }
	
function go_to_vk() {
	if (confirm("Покинуть сайт и перейти на страницу ВК?")){
		window.location.href = "https://vk.com/id248665010";
	}
}